import java.util.Scanner;

public class Test1_김태영 {

	public static void main(String[] args) {
		//---------여기에 코드를 작성하세요.---------------//
		Scanner sc = new Scanner(System.in);
		String str = sc.next();
		if(str.equals("*")) {
			for(int i=0;i<4;i++) {
				for(int j=0;j<i;j++) {
					System.out.printf("%3s","");
				}
				for(int k=4;k>i;k--) {
					System.out.printf("%3s",str);
				}
				System.out.println();
			}
		}
		else {
			for(int i=1; i<=5;i++) {
				System.out.printf("%3d",20+i);
			}
			System.out.println();
			System.out.printf("%3d",20);
		}
		
	}

}
