import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class Test3_김태영 {

	public static void main(String[] args) throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int cal = Integer.parseInt(br.readLine());
		int[] updown = new int[3];
		int idx1=0;
		int[] leftright = new int[3];
		int idx2=0;
		for(int i=0;i<6;i++) {
			StringTokenizer st = new StringTokenizer(br.readLine());
			int turn = Integer.parseInt(st.nextToken());
			int len = Integer.parseInt(st.nextToken());
			if(turn==1|turn==2) {
				leftright[idx2]=len;
				idx2++;
			}
			else if(turn==3|turn==4) {
				updown[idx1]=len;
				idx1++;
			}
		}
		Arrays.sort(updown);
		Arrays.sort(leftright);
		System.out.println(cal*((updown[2]*leftright[2])-(updown[0]*leftright[0])));

	}

}
